import { View, Text } from 'react-native'
import React from 'react'

const Empty = () => {
  return (
    <View>
      <Text style={{marginTop:'50%',textAlign:'center'}}>This Page is under development!!!</Text>
    </View>
  )
}

export default Empty